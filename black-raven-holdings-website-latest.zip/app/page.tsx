const services = [
  { number: "01", title: "Junk Removal", description: "Clear-outs for homes, garages, rentals, and small businesses—with dependable pickup and responsible disposal.", action: "Schedule a pickup", href: "tel:+16129303809" },
  { number: "02", title: "Website Creation", description: "Clean, practical websites for local businesses, independent operators, and new ventures ready to look established.", action: "Start a website", href: "mailto:blackravenholdings@proton.me?subject=Website%20project" },
  { number: "03", title: "Mobile Mechanic", description: "Convenient diagnostics and select automotive repairs brought to you in the Rochester area.", action: "Request service", href: "tel:+16129303809" },
  { number: "04", title: "Liquidations", description: "Organized asset recovery and resale support for estates, business closures, surplus inventory, and clean-outs.", action: "Discuss a project", href: "mailto:blackravenholdings@proton.me?subject=Liquidation%20project" },
  { number: "05", title: "EHS Consulting", description: "Practical environmental, health, and safety support built around your people, operations, and compliance needs.", action: "Request a consultation", href: "mailto:blackravenholdings@proton.me?subject=EHS%20consultation" },
  { number: "06", title: "Social Media Projects", description: "Focused content, campaign, and account support that helps small businesses show up clearly and consistently.", action: "Plan a project", href: "mailto:blackravenholdings@proton.me?subject=Social%20media%20project" },
];

function RavenDogLogo({ inverse = false }: { inverse?: boolean }) {
  return (
    <img
      className={`brand-mark${inverse ? " brand-mark-inverse" : ""}`}
      src="/black-raven-logo.png"
      alt="Black Raven Holdings raven flying above a German Shepherd"
    />
  );
}

function Arrow() { return <span aria-hidden="true">↗</span>; }

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Black Raven Holdings home">
          <RavenDogLogo /><span>Black Raven<br />Holdings</span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#services">Services</a><a href="#about">About</a>
          <a className="nav-cta" href="tel:+16129303809">Call 612-930-3809</a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Rochester, New York · Local &amp; independent</p>
          <h1>Practical help.<br /><em>Built to get it done.</em></h1>
          <p className="hero-lede">One trusted partner for property, automotive, digital, resale, and safety projects.</p>
          <div className="hero-actions">
            <a className="button button-dark" href="#services">Explore services <Arrow /></a>
            <a className="text-link" href="mailto:blackravenholdings@proton.me">Tell us what you need <Arrow /></a>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <span className="orbit orbit-one" /><span className="orbit orbit-two" />
          <RavenDogLogo inverse /><p>Resourceful by nature.</p>
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="section-heading">
          <p className="eyebrow">What we do</p>
          <h2>Six ways we can move your project forward.</h2>
        </div>
        <div className="service-grid">
          {services.map((service) => (
            <article className="service-card" key={service.title}>
              <div className="card-topline"><span>{service.number}</span><span className="card-arrow" aria-hidden="true">↗</span></div>
              <h3>{service.title}</h3><p>{service.description}</p>
              <a href={service.href}>{service.action} <Arrow /></a>
            </article>
          ))}
        </div>
      </section>

      <section className="about-section" id="about">
        <div className="about-mark"><RavenDogLogo inverse /></div>
        <div className="about-copy">
          <p className="eyebrow">Why Black Raven</p>
          <h2>Many capabilities.<br />One resourceful partner.</h2>
          <p>
            Black Raven Holdings brings a hands-on, problem-solving mindset to every job. Whether the project is physical, mechanical, digital, or operational, you get direct communication and practical next steps from a local independent business.
          </p>
          <div className="about-points">
            <span><strong>Local</strong> Rochester-based service</span>
            <span><strong>Direct</strong> One point of contact</span>
            <span><strong>Practical</strong> Solutions sized to the job</span>
          </div>
        </div>
      </section>

      <section className="marketplace-strip">
        <div>
          <p className="eyebrow">Shop recovered parts &amp; finds</p>
          <h2>Black Raven on eBay</h2>
        </div>
        <p>Browse tested automotive parts, useful components, and unique inventory from our liquidation and recovery work.</p>
        <a className="button button-light" href="https://www.ebay.com/usr/blackravenholdingsinc" target="_blank" rel="noreferrer">Visit our eBay store <Arrow /></a>
      </section>

      <section className="contact-section" id="contact">
        <p className="eyebrow">Have a project in mind?</p>
        <h2>Let’s figure out<br /><em>the next move.</em></h2>
        <div className="contact-actions">
          <a href="tel:+16129303809">612-930-3809 <Arrow /></a>
          <a href="mailto:blackravenholdings@proton.me">blackravenholdings@proton.me <Arrow /></a>
        </div>
      </section>

      <footer>
        <a className="footer-brand" href="#top"><RavenDogLogo inverse /><span>Black Raven Holdings, LLC</span></a>
        <div><span>Rochester, NY</span><a href="https://blackravenholdings.org">blackravenholdings.org</a></div>
        <p>© 2026 Black Raven Holdings, LLC</p>
      </footer>
    </main>
  );
}
